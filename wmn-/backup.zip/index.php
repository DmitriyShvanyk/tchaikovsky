<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <title>Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="fonts/CeraPro/stylesheet.css">

    <link rel="icon" type="image/x-icon" href="" />

    <link rel="stylesheet" type="text/css" href="libs/slick/slick.css" />
    <link rel="stylesheet" type="text/css" href="libs/slick/slick-theme.css" />

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/journal.css">
    <link rel="stylesheet" href="css/comments.css">
</head>

<body>
    <?php include("chunks/header.php"); ?>
    <?php include("chunks/comments.php"); ?>
    <?php include("chunks/journal.php"); ?>
    <?php include("chunks/footer.php"); ?>

    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="libs/slick/slick.min.js"></script>

    <script src="js/script.js"></script>
</body>

</html>
