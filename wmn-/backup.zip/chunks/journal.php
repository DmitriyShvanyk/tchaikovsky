<div class="journal">
    <div class="container">
        <h2>Журнал</h2>
        <div class="main">

            <div class="video">
                <img src="i/icon_category_video.png" alt="Category: Video">
                <div class="info d-only">
                    <h3>Как поменять офисную работу на удаленную?</h3>
                    <div class="meta">
                        <p class="date">28.03</p>
                        <p class="views">649</p>
                        <p class="feedback">23</p>
                    </div>
                </div>
            </div>

            <div class="info m-only">
                <h3>Как поменять офисную работу на удаленную?</h3>
                <div class="stats">
                    <p class="date">28.03</p>
                    <p class="views">649</p>
                    <p class="feedback">23</p>
                </div>
            </div>

            <div class="more">

                <div class="item">
                    <div class="img_wrapper">
                        <img src="i/icon_item.png" alt="Article">
                    </div>
                    <div class="info">
                        <p class="title">Как увеличить доход на удаленке?</p>
                        <p class="desc">Прошло полгода? Год? Два года? С того момента, как вы прошли обучение на фрилансе...</p>
                        <div class="stats">
                            <p class="date">28.03</p>
                            <p class="views">649</p>
                            <p class="feedback">23</p>
                        </div>
                    </div>
                </div>

                <div class="item">
                    <div class="img_wrapper">
                        <img src="i/icon_item.png" alt="Article">
                    </div>
                    <div class="info">
                        <p class="title">Как плавно перейти на удаленку, не бросая основную работу?</p>
                        <p class="desc">Многие хотят перейти на фриланс, но их останавливает страх. Спокойно! Больше никаких сомнений...</p>
                        <div class="stats">
                            <p class="date">28.03</p>
                            <p class="views">649</p>
                            <p class="feedback">23</p>
                        </div>
                    </div>
                </div>

                <div class="item">
                    <div class="img_wrapper">
                        <img src="i/icon_item.png" alt="Article">
                    </div>
                    <div class="info">
                        <p class="title">Какие профессии на удаленке принесут тебе доход?</p>
                        <p class="desc">Боишься, что поменяешь найм на удаленку и не сможешь найти свое место? Не беспокойся...</p>
                        <div class="stats">
                            <p class="date">28.03</p>
                            <p class="views">649</p>
                            <p class="feedback">23</p>
                        </div>
                    </div>
                </div>

                <div class="item">
                    <div class="img_wrapper">
                        <img src="i/icon_item.png" alt="Article">
                    </div>
                    <div class="info">
                        <p class="title">Какие профессии на удаленке принесут тебе доход?</p>
                        <p class="desc">Боишься, что поменяешь найм на удаленку и не сможешь найти свое место? Не беспокойся...</p>
                        <div class="stats">
                            <p class="date">28.03</p>
                            <p class="views">649</p>
                            <p class="feedback">23</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="other">

            <div class="item">
                <div class="thumbnail audio"></div>
                <p class="title">Как создать свой рай на земле</p>
                <div class="stats">
                    <p class="date">28.03</p>
                    <p class="views">649</p>
                    <p class="feedback">23</p>
                </div>
            </div>

            <div class="item">
                <div class="thumbnail bars"></div>
                <p class="title">Алексей Мышкин: Как преодолеть страх перемен и последовать за своей мечтой</p>
                <div class="stats">
                    <p class="date">28.03</p>
                    <p class="views">649</p>
                    <p class="feedback">23</p>
                </div>
            </div>

            <div class="item">
                <div class="thumbnail bars"></div>
                <p class="title">Как избавиться от предрассудков и раскрыть в себе женщину</p>
                <div class="stats">
                    <p class="date">28.03</p>
                    <p class="views">649</p>
                    <p class="feedback">23</p>
                </div>
            </div>

        </div>
    </div>
</div>
