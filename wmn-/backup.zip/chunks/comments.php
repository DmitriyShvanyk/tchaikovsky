<div class="comments">
    <div class="container">

        <div class="comment">
            <div class="photo">
                <img src="i/person1.png" alt="Photo">
            </div>
            <div class="content">
                <p class="author">Гульназ Ф.</p>
                <p class="text">На удаленке я могу и о детях позаботиться, и зарабатывать хорошие деньги, и даже путешествовать.</p>
            </div>
        </div>

        <div class="comment">
            <div class="photo">
                <img src="i/person2.png" alt="Photo">
            </div>
            <div class="content">
                <p class="author">Анна Л.</p>
                <p class="text">Я решила освоить новые навыки, чтобы получить возможность зарабатывать любимым занятием.</p>
            </div>
        </div>

        <div class="comment">
            <div class="photo">
                <img src="i/person3.png" alt="Photo">
            </div>
            <div class="content">
                <p class="author">Афанасия Ю.</p>
                <p class="text">Мысль о том, что я могу приносить пользу людям и получать за это деньги, определила мой выбор.</p>
            </div>
        </div>

        <div class="comment">
            <div class="photo">
                <img src="i/person4.png" alt="Photo">
            </div>
            <div class="content">
                <p class="author">Алла А.</p>
                <p class="text">Поняла, что работа проджект-менеджера позволяет объединить мой опыт и все, чему я обучалась на курсе.</p>
            </div>
        </div>

    </div>
</div>
