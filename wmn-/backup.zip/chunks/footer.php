<div class="footer">
    <div class="container">
        <div class="top">
            <div class="left">
                <img src="i/logo_gray.svg" alt="Logo Gray" class="logo_gray">
                <a href="" class="">Главная</a>
                <a href="" class="">Журнал</a>
                <a href="" class="">Мероприятия</a>
                <a href="" class="">Контакты</a>
            </div>
            <div class="right">
                <p>Звоните: <a href="tel: +7 (499) 938 51 90" class="phone">+7 (499) 938 51 90</a> Пишите: <a href="mailto: info@wmn.work">info@wmn.work</a></p>
            </div>
        </div>
        <div class="bottom">
            <a href="">Copyright © 2021 wmn.work</a>
            <a href="">Все права защищены</a>
            <a href="" class="lined">Политика конфиденциальности</a>
            <a href="" class="lined">Правила пользования</a>
            <a href="" class="lined">Отказ от ответственности</a>
            <div class="social">
                <a href="" class="instagram">
                    <img src="i/social_ig.png" alt="Instagram">
                </a>
                <a href="" class="telegram">
                    <img src="i/social_tg.png" alt="Telegram">
                </a>
                <a href="" class="youtube">
                    <img src="i/social_yt.png" alt="YouTube">
                </a>
                <a href="" class="vk">
                    <img src="i/social_vk.png" alt="VKontakte">
                </a>
            </div>
        </div>
    </div>
</div>
