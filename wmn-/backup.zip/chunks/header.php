<div class="header">
    <img src="i/waves.png" alt="Waves" class="waves d-only">
    <img src="i/specular.png" alt="Doodad" class="doodad d-only">
    <img src="i/Chatbox.png" alt="Chatbox" class="chatbox d-only">

    <img src="i/waves_mobile.png" alt="Waves" class="waves_m m-only">
    <img src="i/specular2.png" alt="Doodad" class="doodad_m m-only">

    <div class="container">
        <div class="navbar">
            <img src="i/logo_white.svg" alt="Logo" class="logo">
            <a href="" class="d-only">Журнал</a>
            <a href="" class="d-only">О проекте</a>
            <button class="d-only">Войти</button>
            <a href="" class="bars m-only"><img src="i/bars.png" alt="Menu"></a>
        </div>
        <div class="content">
            <h1>Помогаем женщинам <br> найти надежную <br> удаленную работу</h1>
            <img src="i/photo-m.png" alt="Photo" class="photo_m m-only">
            <div class="list">
                <p class="tick">
                    <svg class="d-only" width="17" height="18" viewBox="0 0 17 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 11.0169L5.84615 16L16 1" stroke="white" stroke-width="2" stroke-linecap="round" />
                    </svg>
                    Выбрать направление
                </p>
                <p>Освоить онлайн-профессию</p>
                <p>Найти работодателя</p>
            </div>
            <a href="#" class="btn">Начать бесплатно</a>
        </div>
        <img src="i/photo-d.png" alt="Photo" class="photo d-only">
    </div>

</div>
