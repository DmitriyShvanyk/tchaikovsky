<div class="about">
    <div class="container">
        <img src="i/wmnwork.png" alt="Logo">
        <p class="desc"><b>wmn.work</b> — проект, созданный для женщин. Для тех, которые стремятся обрести свободу выбирать свое расписание и место для жизни, независимость от рутины и жесткого офисного расписания. Для тех, кто хочет реализовать себя и начать новый виток в своей карьере.</p>
        <p class="additional">Мы помогаем выявить свои сильные стороны, обрести необходимые навыки, выбрать самую перспективную и подходящую профессию, побороть все страны и сомнения, найти первых заказчиков и безболезненно перейти на удаленную работу.</p>
        <div class="infocard">
            <p class="head">Основатели <br> проекта</p>
            <img src="i/photo-duo.png" alt="Duo" class="photo-duo">
            <hr class="fullwidth m-only">
            <p class="name"><b>Антон Кратасюк</b></p>
            <p class="achievements">Предприниматель, продюсер, врач <br> Основатель компании Mindcity <br> Управляет удаленной командой >100 человек <br> Со-основатель wmn.work</p>
            <p class="name"><b>Эля Ходус</b></p>
            <p class="achievements">13 лет работает онлайн <br> Основатель проекта Profrelance <br> Выпустила более 10 000 студентов <br> Со-основатель wmn.work</p>
        </div>

        <p class="head">Факультеты в цифрах</p>
        <p class="info">Наши ученицы могут выбрать один из четырех факультетов «Тексты», «Люди», <br class="d-only"> «Данные» или «Визал», чтобы освоить перспективную удаленную профессию.</p>

        <div class="stats">

            <div class="item">
                <p class="cat"><img src="i/icon_stats_texts.png" alt="Texts">Тексты</p>
                <div class="numbers">
                    <div>
                        <p>266</p>
                        <p class="what">студентов</p>
                    </div>
                    <div>
                        <p>188</p>
                        <p class="what">заказов</p>
                    </div>
                </div>
            </div>

            <div class="item">
                <p class="cat"><img src="i/icon_stats_people.png" alt="People">Люди</p>
                <div class="numbers">
                    <div>
                        <p>149</p>
                        <p class="what">студентов</p>
                    </div>
                    <div>
                        <p>104</p>
                        <p class="what">заказов</p>
                    </div>
                </div>
            </div>

            <div class="item">
                <p class="cat"><img src="i/icon_stats_data.png" alt="Data">Данные</p>
                <div class="numbers">
                    <div>
                        <p>211</p>
                        <p class="what">студентов</p>
                    </div>
                    <div>
                        <p>118</p>
                        <p class="what">заказов</p>
                    </div>
                </div>
            </div>

            <div class="item">
                <p class="cat"><img src="i/icon_stats_visual.png" alt="Visual">Визуал</p>
                <div class="numbers">
                    <div>
                        <p>122</p>
                        <p class="what">студентов</p>
                    </div>
                    <div>
                        <p>33</p>
                        <p class="what">заказов</p>
                    </div>
                </div>
            </div>

        </div>

        <hr class="d-only">

        <p class="closure">За 5 недель предыдущего потока наши студентки выполнили <br class="d-only"> 454 заказа и заработали суммарно <b>449 893 ₽</b></p>
    </div>
</div>
