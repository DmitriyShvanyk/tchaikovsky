<div class="generic">
    <div class="bgimg"></div>
    <div class="container head">
        <h1>Помогаем женщинам найти надежную <br> удаленную работу</h1>
        <a href="" class="btn-main">Начать бесплатно
            <img src="i/arrow-right-orange.png" alt="Arrow" class="d-only">
            <img src="i/arrow-right.png" alt="Arrow" class="m-only">
        </a>
    </div>
    <div class="navbar">
        <div class="container">
            <img src="i/logo_white.svg" alt="Logo" class="logo">
            <span class="links d-only">
                <a href="" class="link active">Журнал</a>
                <a href="" class="link">О проекте</a>
                <a href="" class="link login">Войти</a>
            </span>
            <a href="" class="bars m-only"><img src="i/bars.png" alt="Menu"></a>
        </div>
    </div>
</div>
