<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <title>Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="fonts/CeraPro/stylesheet.css">

    <link rel="icon" type="image/x-icon" href="" />

    <link rel="stylesheet" type="text/css" href="libs/slick/slick.css" />
    <link rel="stylesheet" type="text/css" href="libs/slick/slick-theme.css" />

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/generic.css">
    <link rel="stylesheet" href="css/journal.css">
    <link rel="stylesheet" href="css/about.css">
    <link rel="stylesheet" href="css/footer.css">

    <style>
        @media (max-width: 991px) {
            .about img[alt="Logo"] {
                max-width: 80px;
                margin-bottom: 17px;
            }

            .about p.desc {
                font-weight: 500;
                font-size: 24px;
                line-height: 150%;
            }

            .about p.desc b {
                font-weight: 700;
            }

            .about p.additional {
                margin-bottom: 52px;

                font-size: 18px;
                line-height: 150%;
            }

            .about .infocard {
                padding: 41px 20px;
                margin-left: unset;
                margin-right: unset;
            }

            .about .infocard p {
                font-size: 18px;
            }

            .about p.head {
                margin-bottom: 10px;

                font-size: 36px;
                line-height: 110%;
            }

            .about .infocard {
                margin-bottom: 41px;
            }

            .about .infocard p.head {
                margin-bottom: 13px;
            }

            .about .infocard img.photo-duo {
                max-width: 125%;
                position: relative;
                display: block;
                left: -30px;

            }

            .about hr.fullwidth {
                margin-bottom: 31px;
                border: none;
                border-top: 1px solid rgba(37, 35, 42, 0.1);
                margin-left: -20px;
                margin-right: -20px;
            }

            .about p.info {
                margin-bottom: 29px;
                font-size: 18px;
                line-height: 150%;
            }

            .about .stats {
                display: block;
                margin-bottom: 32px;
            }

            .about .stats .item {
                margin-bottom: 26px;
                border-bottom: 1px solid #EFEFEF;
            }

            .about .stats .item .numbers {
                margin-bottom: 26px;
            }

            .about .stats .item .numbers>div {
                width: 100%;
            }

            .about .stats .item .numbers>div:first-child {
                margin-right: unset;
            }

            .about p.closure {
                font-size: 28px;
                line-height: 140%;
            }

            .about p.closure {
                margin-bottom: 54px;
            }

        }

    </style>
</head>

<body>
    <?php include("chunks/generic.php"); ?>
    <?php include("chunks/about.php"); ?>
    <?php include("chunks/footer.php"); ?>

    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="libs/slick/slick.min.js"></script>

    <script src="js/script.js"></script>
</body>

</html>
