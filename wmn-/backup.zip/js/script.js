$('.comments .container').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 992,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1
        }
            }]
});


$(".journal .more").slick({
    dots: false,
    infinite: false,
    speed: 300,
    vertical: true,
    verticalSwiping: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 992,
        settings: {
            vertical: false,
            verticalSwiping: false,
            slidesToShow: 1,
            slidesToScroll: 1
        }
            }]
});
